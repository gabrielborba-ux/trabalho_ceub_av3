@echo off
title Pipeline Big Data CEUB - AV3
color 0A
echo ============================================================
echo   INICIANDO PIPELINE DE BIG DATA - CEUB (AV3)
echo ============================================================
echo.
echo [1/3] Verificando dependencias Python...
python -m pip install -q pandas pyarrow streamlit plotly

echo.
echo [2/3] Executando Pipeline ETL (Bronze -> JSON -> Silver/Gold Parquet -> DB)...
python pipeline_completo.py

echo.
echo [3/3] Abrindo Dashboard Interativo no Navegador...
echo (Se pedir Email, basta apertar ENTER. Mantenha esta janela aberta!)
echo.
python -m streamlit run dashboard.py
pause
