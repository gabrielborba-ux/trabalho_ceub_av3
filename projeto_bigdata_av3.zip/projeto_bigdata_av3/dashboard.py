import sqlite3
import pandas as pd
import plotly.express as px
import streamlit as st

st.set_page_config(page_title="Air Quality Analytics - CEUB", layout="wide")
st.title("Air Quality Analytics — Pipeline de Big Data (CEUB)")
st.caption("Arquitetura Lakehouse: Bronze (CSV) → Ingestão JSON → Silver (Parquet) → Gold (Parquet + SQLite) → Streamlit")

conn = sqlite3.connect("datalake/analytics.db")
df = pd.read_sql("SELECT * FROM air_quality_gold ORDER BY event_timestamp", conn)
conn.close()

c1, c2, c3, c4 = st.columns(4)
c1.metric("Registros Processados", len(df))
c2.metric("Temperatura Média", f"{df['temperature'].mean():.1f} °C")
c3.metric("CO Médio", f"{df['co_gt'].mean():.2f} mg/m³")
c4.metric("Alertas Críticos", int((df["air_status"] == "ALERTA_CRITICO").sum()))

st.divider()

st.subheader("Concentração de CO por horário")
df_hourly = df.groupby("hour_of_day", as_index=False)["co_gt"].mean().sort_values("hour_of_day")
df_hourly["hora_fmt"] = df_hourly["hour_of_day"].apply(lambda h: f"{int(h):02d}h")

fig = px.line(
    df_hourly,
    x="hora_fmt",
    y="co_gt",
    markers=True,
    labels={"hora_fmt": "Horário", "co_gt": "Concentração CO (mg/m³)"},
)
st.plotly_chart(fig, use_container_width=True)

st.subheader("Dados Tratados (Camada Silver/Gold)")
status_sel = st.multiselect("Filtrar por Status:", options=df["air_status"].unique(), default=df["air_status"].unique())
st.dataframe(df[df["air_status"].isin(status_sel)], use_container_width=True)
