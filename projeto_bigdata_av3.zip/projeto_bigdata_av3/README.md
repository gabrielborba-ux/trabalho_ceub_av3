# Projeto Pipeline de Dados — Big Data (CEUB - AV3)

## Como executar (2 cliques)
1. Dê um duplo clique no arquivo **`INICIAR_TUDO.bat`**.
2. O script executa automaticamente a ingestão JSON, o processamento ETL nas camadas **Bronze**, **Silver (Parquet)** e **Gold (Parquet + Banco Analítico)**, valida as saídas e abre o **Dashboard Streamlit** no navegador.
